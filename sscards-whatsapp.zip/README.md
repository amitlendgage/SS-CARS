# S S Cards Technology - WhatsApp AI bot + catalog web app

- `api/webhook.js`  WhatsApp webhook; Claude writes the replies
- `public/index.html`  catalog web app (opened from the "Open catalog" button)

## Setup
1. Edit `WA_NUMBER` in `public/index.html` (country code + number, digits only).
2. Push to GitHub (or run `vercel` in this folder) and import in Vercel. Framework preset: Other.
3. In Vercel > Settings > Environment Variables, add everything from `.env.example`, then redeploy.
4. In Meta for Developers > WhatsApp > Configuration, set:
   - Callback URL: `https://YOUR-PROJECT.vercel.app/api/webhook`
   - Verify token: the same `VERIFY_TOKEN`
   - Subscribe to the `messages` field.
5. Message your WhatsApp number to test.
